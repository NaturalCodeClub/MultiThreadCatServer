package catserver.server.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.List;

public class getThreadNames extends Command {
    static ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
    {
        threadMXBean.setThreadCpuTimeEnabled(true);
    }

    public getThreadNames(String name) {
        super(name);
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        List<String> names = new ArrayList<>();
        long[] ids = threadMXBean.getAllThreadIds();
        for(long id:ids){
            names.add(threadMXBean.getThreadInfo(id).getThreadName());
        }
        sender.sendMessage("Threads:");
        for (String name:names){
            sender.sendMessage(name);
        }
        return true;
    }
}
